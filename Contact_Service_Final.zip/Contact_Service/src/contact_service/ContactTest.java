package contact_service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Contact class.
 * Tests verify all field constraints and validation rules.
 */
public class ContactTest {
    
    // Test successful creation of a contact with valid data
    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        
        assertEquals("1234567890", contact.getContactId());
        assertEquals("Jeremy", contact.getFirstName());
        assertEquals("White", contact.getLastName());
        assertEquals("5551234567", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }
    
    // Test contactId cannot be null
    @Test
    public void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Jeremy", "White", "5551234567", "123 Main St");
        });
    }
    
    // Test contactId cannot exceed 10 characters
    @Test
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Jeremy", "White", "5551234567", "123 Main St");
        });
    }
    
    // Test firstName cannot be null
    @Test
    public void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", null, "White", "5551234567", "123 Main St");
        });
    }
    
    // Test firstName cannot exceed 10 characters
    @Test
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "12345678901", "White", "5551234567", "123 Main St");
        });
    }
    
    // Test lastName cannot be null
    @Test
    public void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Jeremy", null, "5551234567", "123 Main St");
        });
    }
    
    // Test lastName cannot exceed 10 characters
    @Test
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Jeremy", "12345678901", "5551234567", "123 Main St");
        });
    }
    
    // Test phone cannot be null
    @Test
    public void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Jeremy", "White", null, "123 Main St");
        });
    }
    
    // Test phone must be exactly 10 digits (too short)
    @Test
    public void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Jeremy", "White", "555123456", "123 Main St");
        });
    }
    
    // Test phone must be exactly 10 digits (too long)
    @Test
    public void testPhoneTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Jeremy", "White", "55512345678", "123 Main St");
        });
    }
    
    // Test address cannot be null
    @Test
    public void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Jeremy", "White", "5551234567", null);
        });
    }
    
    // Test address cannot exceed 30 characters
    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Jeremy", "White", "5551234567", "1234567890123456789012345678901");
        });
    }
    
    // Test updating firstName with valid value
    @Test
    public void testUpdateFirstNameSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        contact.setFirstName("Ashley");
        assertEquals("Ashley", contact.getFirstName());
    }
    
    // Test updating lastName with valid value
    @Test
    public void testUpdateLastNameSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        contact.setLastName("White");
        assertEquals("White", contact.getLastName());
    }
    
    // Test updating phone with valid value
    @Test
    public void testUpdatePhoneSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        contact.setPhone("5559876543");
        assertEquals("5559876543", contact.getPhone());
    }
    
    // Test updating address with valid value
    @Test
    public void testUpdateAddressSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        contact.setAddress("456 Oak Ave");
        assertEquals("456 Oak Ave", contact.getAddress());
    }
}
package contact_service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the ContactService class.
 * Tests verify add, delete, and update operations.
 */
public class ContactServiceTest {
    
    private ContactService service;
    
    // Set up a fresh ContactService before each test
    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }
    
    // Test adding a contact successfully
    @Test
    public void testAddContactSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        Contact retrieved = service.getContact("1234567890");
        assertEquals("Jeremy", retrieved.getFirstName());
    }
    
    // Test adding a contact with duplicate ID fails
    @Test
    public void testAddContactDuplicateId() {
        Contact contact1 = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        Contact contact2 = new Contact("1234567890", "Ashley", "White", "5559876543", "456 Oak Ave");
        
        service.addContact(contact1);
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }
    
    // Test adding null contact fails
    @Test
    public void testAddContactNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }
    
    // Test deleting a contact successfully
    @Test
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        service.deleteContact("1234567890");
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("1234567890");
        });
    }
    
    // Test deleting a non-existent contact fails
    @Test
    public void testDeleteContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("9999999999");
        });
    }
    
    // Test deleting with null ID fails
    @Test
    public void testDeleteContactNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact(null);
        });
    }
    
    // Test updating firstName successfully
    @Test
    public void testUpdateFirstNameSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        service.updateFirstName("1234567890", "Ashley");
        
        assertEquals("Ashley", service.getContact("1234567890").getFirstName());
    }
    
    // Test updating firstName with invalid value fails
    @Test
    public void testUpdateFirstNameInvalid() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("1234567890", "12345678901");
        });
    }
    
    // Test updating lastName successfully
    @Test
    public void testUpdateLastNameSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        service.updateLastName("1234567890", "White");
        
        assertEquals("White", service.getContact("1234567890").getLastName());
    }
    
    // Test updating lastName with invalid value fails
    @Test
    public void testUpdateLastNameInvalid() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateLastName("1234567890", null);
        });
    }
    
    // Test updating phone successfully
    @Test
    public void testUpdatePhoneSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        service.updatePhone("1234567890", "5559876543");
        
        assertEquals("5559876543", service.getContact("1234567890").getPhone());
    }
    
    // Test updating phone with invalid value fails
    @Test
    public void testUpdatePhoneInvalid() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("1234567890", "123");
        });
    }
    
    // Test updating address successfully
    @Test
    public void testUpdateAddressSuccess() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        service.updateAddress("1234567890", "456 Oak Ave");
        
        assertEquals("456 Oak Ave", service.getContact("1234567890").getAddress());
    }
    
    // Test updating address with invalid value fails
    @Test
    public void testUpdateAddressInvalid() {
        Contact contact = new Contact("1234567890", "Jeremy", "White", "5551234567", "123 Main St");
        service.addContact(contact);
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAddress("1234567890", "1234567890123456789012345678901");
        });
    }
    
    // Test updating contact that Doesn't exist fails
    @Test
    public void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("9999999999", "Ashley");
        });
    }
}
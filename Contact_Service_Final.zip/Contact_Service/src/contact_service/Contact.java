package contact_service; //Had to add this or it would not let me create the classes

public class Contact {
    // Contact ID: required, unique, max 10 chars, cannot be null
    private final String contactId;
    
    // First name: required, max 10 chars, cannot be null
    private String firstName;
    
    // Last name: required, max 10 chars, cannot be null
    private String lastName;
    
    // Phone: required, exactly 10 digits, cannot be null
    private String phone;
    
    // Address: required, max 30 chars, cannot be null
    private String address;
    
    /**
     * Constructor to create a new Contact object.
     * All parameters are validated before assignment.
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        // Validate and set contactId
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Contact ID must not be null and must be 10 characters or less");
        }
        this.contactId = contactId;
        
        // Validate and set other fields using setters
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }
    
    // Getter for contactId
    public String getContactId() {
        return contactId;
    }
    
    // Getter and setter for firstName
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First name must not be null and must be 10 characters or less");
        }
        this.firstName = firstName;
    }
    
    // Getter and setter for lastName
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name must not be null and must be 10 characters or less");
        }
        this.lastName = lastName;
    }
    
    // Getter and setter for phone
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Phone must not be null and must be exactly 10 digits");
        }
        this.phone = phone;
    }
    
    // Getter and setter for address
    public String getAddress() {
        return address;
    }
    
    // Can increase length if needed
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address must not be null and must be 30 characters or less");
        }
        this.address = address;
    }
}